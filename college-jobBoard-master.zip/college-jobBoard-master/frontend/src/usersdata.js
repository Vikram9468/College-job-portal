 export var usersdata=[
    {
        id:1,
        username:"3379",
        password:"3379",
        appliedjobs:[
            {
                jobid:"001",
                jobrole:"SDE",
                description:"u need to do front end dev",
                enddate:"15-05-2023"
            },
            {
                jobid:"002",
                jobrole:"SDE",
                description:"u need to do front end dev",
                enddate:"15-05-2023"
            },
            {
                jobid:"003",
                jobrole:"SDE",
                description:"u need to do front end dev",
                enddate:"15-05-2023"
            }
            
        ]
    },
    {
        id:2,
        username:"3369",
        password:"3369",
        appliedjobs:[
            {
                jobid:"011",
                jobrole:"SDE",
                description:"u need to do front end dev",
                enddate:"15-05-2023"
            },
            {
                jobid:"012",
                jobrole:"SDE",
                description:"u need to do front end dev",
                enddate:"15-05-2023"
            },
            {
                jobid:"013",
                jobrole:"SDE",
                description:"u need to do front end dev",
                enddate:"15-05-2023"
            }
            
        ]
    }
]

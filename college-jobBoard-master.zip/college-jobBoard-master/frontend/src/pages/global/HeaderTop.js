import { Typography } from '@mui/material'
import Box from '@mui/material/Box'
import React from 'react'

function HeaderTop() {
  return (
    <Box sx={{ width: "100%",height:"5vh",color:"white",backgroundColor:"#2e73ab",display:"flex",alignItems:"center",justifyContent:"center"}}>CVR College of Engineering</Box>
    // <Typography sx={{color:"white"}}>HeaderTop</Typography>
  )
}

export default HeaderTop
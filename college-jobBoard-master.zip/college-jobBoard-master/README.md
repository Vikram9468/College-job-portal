# College Job Board
  College Job Board is a one stop solution for College Placement Department and Students for a hazzle free communication regarding campus drives. 
## Original Problem : 
  In College placements, campus drives are posted through emails, students respond their interest through google forms, fill excel sheets and acknowledge in whatsapp groups, which are not easy to track
## Solution : 
  This application helps Students apply for campus drives with a single click and help placement department to view all responses for a particular drive within the job section itself.
## Features: 
### Admin(Placement Department):
Login , Register Students (individual or in bulk) , Edit/Delete Students , Post Job, Edit/Delete Job , View Responses for a particular job.
### Student :
Login, View Profile, Apply for job, View Applied jobs count
### Demo Link
[![CollegeJobBoardDemo]](https://1drv.ms/v/s!Ajgp7JScBMswo6A7ckFRSGrL9CPtqg)
